class question{
    constructor(question,choice1,choice2,choice3){
        this.question = question;
        this._choice1 = choice1 ;
        this._choice2 = choice2 ;
        this._choice3 = choice3 ;
        this._ans = [this._choice1,this._choice2,this._choice3];
    }
    setCorrect(i) {
        this._correct = this._ans[--i];
        return true;
    }
    getCorrect(){
        return this._correct;
    }
    setAns(i,str){
        this._ans[--i] = 'str';
        return true;
    }
    getAns(i){
        return this._ans[--i];
    }
    toString(){
        return `Questions ${this.question}
Choice 1 : ${this._ans[0]} 
Choice 2 : ${this._ans[1]} 
Choice 3 : ${this._ans[2]}`
    }
}

class player{
    score = 0;
    constructor(name){
        this._name = name;
    }
    getName(){
        return this._name;
    }
    setName(newName){
        this._name = newName;
    }
    getScore(){
        return this.score;
    }
    toString(){
        return `Name player : ${this._name}
Score : ${this.score}`;
    }
}

function check(question , ans){
    if(question.getCorrect() == question.getAns(ans)){
        return true;
    }else
        return false;
}

function plusScore(player){
    player.score += 1;
    return true;
}

function play(player,question,answer){
    if(check(question,answer) == true){
        plusScore(player);
        return true;
    }else
        return false;
}

let p1 = new player('Tle');
let q1 = new question('Why you so handsome?','ธรรมดาว่ะน้อง','พี่มันเลือกเกิดไม่ได้','จิงหรอวะ');
console.log(p1.toString());
console.log(q1.toString());
q1.setCorrect(1);
play(p1,q1,1);
console.log(p1.toString());



